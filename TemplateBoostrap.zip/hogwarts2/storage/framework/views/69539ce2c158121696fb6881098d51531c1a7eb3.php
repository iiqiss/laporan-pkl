
<?php $__env->startSection('content'); ?>
<div class="row">
<h1>Welcome to the Hogwarts school website</h1>

<!-- Earnings (Monthly) Card Example -->
</div>

<!-- Content Row -->

<div class="row">

<!-- Area Chart -->

</div>

<!-- Content Row -->
<div class="row">

<!-- Content Column -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hogwarts2\resources\views/dashboard.blade.php ENDPATH**/ ?>